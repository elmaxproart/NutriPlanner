// src/screens/MapScreen.tsx - Version test avec géolocalisation
import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useGeolocation } from '../hooks/useGeolocation';
import { LoadingSpinner } from '../components/common/LoadingSpinner';

export const MapScreen: React.FC = () => {
  const { location, loading, error, refreshLocation } = useGeolocation();

  const handleTestButton = () => {
    Alert.alert('Test', 'MapScreen fonctionne !');
  };

  const handleRefreshLocation = () => {
    refreshLocation();
  };

  if (loading) {
    return <LoadingSpinner message="Récupération de votre position..." />;
  }

  if (error) {
    return (
      <View style={styles.container}>
        <Text style={styles.errorTitle}>Erreur de géolocalisation</Text>
        <Text style={styles.errorText}>{error}</Text>
        <TouchableOpacity style={styles.retryButton} onPress={handleRefreshLocation}>
          <Text style={styles.retryButtonText}>Réessayer</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>MapScreen - Test Géolocalisation</Text>

      {location ? (
        <View style={styles.locationContainer}>
          <Text style={styles.locationTitle}>📍 Votre position :</Text>
          <Text style={styles.locationText}>
            Latitude: {location.latitude.toFixed(6)}
          </Text>
          <Text style={styles.locationText}>
            Longitude: {location.longitude.toFixed(6)}
          </Text>
          <Text style={styles.locationNote}>
            {__DEV__ ? '(Position simulée - Yaoundé)' : '(Position réelle)'}
          </Text>
        </View>
      ) : (
        <Text style={styles.noLocationText}>Aucune position disponible</Text>
      )}

      <TouchableOpacity style={styles.testButton} onPress={handleTestButton}>
        <Text style={styles.testButtonText}>Tester Alert</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.refreshButton} onPress={handleRefreshLocation}>
        <Text style={styles.refreshButtonText}>Actualiser Position</Text>
      </TouchableOpacity>

      <View style={styles.infoContainer}>
        <Text style={styles.infoTitle}>Statut :</Text>
        <Text style={styles.infoText}>• Hook géolocalisation: ✅</Text>
        <Text style={styles.infoText}>• LoadingSpinner: ✅</Text>
        <Text style={styles.infoText}>• Types: ✅</Text>
        <Text style={styles.infoText}>• Position: {location ? '✅' : '❌'}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
    textAlign: 'center',
  },
  locationContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
    width: '100%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  locationTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  locationText: {
    fontSize: 16,
    color: '#666',
    marginBottom: 5,
    fontFamily: 'monospace',
  },
  locationNote: {
    fontSize: 12,
    color: '#999',
    fontStyle: 'italic',
    marginTop: 5,
  },
  noLocationText: {
    fontSize: 16,
    color: '#dc3545',
    marginBottom: 20,
  },
  testButton: {
    backgroundColor: '#007bff',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 8,
    marginBottom: 10,
  },
  testButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  refreshButton: {
    backgroundColor: '#28a745',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 8,
    marginBottom: 20,
  },
  refreshButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
  infoContainer: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    width: '100%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  infoTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  infoText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  errorTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#dc3545',
    marginBottom: 10,
  },
  errorText: {
    fontSize: 16,
    color: '#dc3545',
    textAlign: 'center',
    marginBottom: 20,
  },
  retryButton: {
    backgroundColor: '#dc3545',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 8,
  },
  retryButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: 'bold',
  },
});